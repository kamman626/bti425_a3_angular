import { Form, Container, Button } from "react-bootstrap";
import { useState } from "react";
import {useFormik} from 'formik';
import * as Yup from "yup"; 

import './App.css';

function App() {

  const [completed, setCompleted] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState(null);

  const formik = useFormik({
    initialValues: {
      fname: '',
      lname: '',
      email: '',
      age: 0
    },
    validationSchema: Yup.object({
      fname: Yup.string().required("First name is require").min(3,"First name must be at least 3 character"),
      lname: Yup.string().required("Last name is require").min(3,"Last name must be at least 3 character"),
      email: Yup.string().email("invalid email address").required("Email is require"),
      age:  Yup.number().required("Age is require").min(18,"Miniumum age must be 18").max(99,"Maximum age is 99")
    }),
    onSubmit: (values) =>{
      console.log(values);
      setCompleted(true);
      setMessage("Submit Successful ! Fast Name: "
                + values.fname  + 
                ", Lirst Name: "
                + values.lname  +
                ", Email: "
                + values.email  +
                ", Age: "
                + values.age)
    }
  });


  if(error){
    console.log("error", error);
  }

  return (
    <Container>
    <h1>Form Validated manually</h1>
    <h2>BTI425_lab5_Kam_Chan</h2>     
    <p>For the forn to be valid:</p>
    <ul>
      <li>All fields must be field</li>
      <li>First and last name must be at least three characters</li>
      <li>Age must be between 18 and 99</li>
    </ul>

    <Form onSubmit = {formik.handleSubmit}>
      <Form.Group>
        <Form.Label>First Name</Form.Label>
        <Form.Control
          id="fname"
          name="fname"
          type="text"
          placeholder="Enter your first name"
          value = {formik.values.fname}
          onChange={formik.handleChange}
        />
        {formik.touched.fname && formik.errors.fname ? (
          <Form.Text className="text-muted">{formik.errors.fname}</Form.Text>
        ) : null}
      </Form.Group>

      <Form.Group>
        <Form.Label>Last Name</Form.Label>
        <Form.Control
          id="lname"
          name="lname"
          type="text"
          placeholder="Enter your last name"
          value = {formik.values.lname}
          onChange={formik.handleChange}
        />
        {formik.touched.lname && formik.errors.lname ? (
          <Form.Text className="text-muted">{formik.errors.lname}</Form.Text>
        ) : null}
      </Form.Group>

      <Form.Group>
        <Form.Label>Email</Form.Label>
        <Form.Control
          id="email"
          name="email"
          type="email"
          placeholder="Enter your email address"
          value = {formik.values.email}
          onChange={formik.handleChange}
        />
        {formik.touched.email && formik.errors.email ? (
          <Form.Text className="text-muted">{formik.errors.email}</Form.Text>
        ) : null}
      </Form.Group>

      <Form.Group>
        <Form.Label>age</Form.Label>
        <Form.Control
          id="age"
          name="age"
          type="number"
          placeholder="Enter your age"
          value = {formik.values.age}
          onChange={formik.handleChange}
        />
        {formik.touched.age && formik.errors.age ? (
          <Form.Text className="text-muted">{formik.errors.age}</Form.Text>
        ) : null}
      </Form.Group>

      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
    {completed ? <h3>{message}</h3>: null}
  </Container>
  );
}

export default App;
